create
    definer = root@localhost procedure getAll()
BEGIN

    select * from users;

END;

