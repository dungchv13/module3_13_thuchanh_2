create
    definer = root@localhost procedure update_user(IN user_id int, IN user_name varchar(50), IN user_email varchar(50),
                                                   IN user_country varchar(50))
BEGIN

    UPDATE users
        SET name = user_name,email = user_email,country = user_country
    where id = user_id;

END;

