create
    definer = root@localhost procedure deleteUser(IN user_id int)
BEGIN

    delete from users where id = user_id;

END;

